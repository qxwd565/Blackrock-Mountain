Shader "Custom/FX_GhostCard" {
Properties {
 _Color ("Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _MainTex ("Main Texture", 2D) = "black" {}
 _TexIntensity ("Main Texture Intensity", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _FxTex ("FX Texture", 2D) = "black" {}
 _FxIntensity ("FX Intensity", Float) = 1
 _FxDistortion ("FX Distortion", Float) = 1
 _ScrollX ("FX Scroll X", Float) = 0
 _ScrollY ("FX Scroll Y", Float) = 0
 _ScaleX ("FX Scale X", Float) = 1
 _ScaleY ("FX Scale Y", Float) = 1
 _Seed ("Seed", Float) = 0
}
SubShader { 
 Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
 Pass {
  Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  ZWrite Off
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
  Blend One OneMinusSrcAlpha
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

attribute vec4 _glesVertex;
attribute vec4 _glesColor;
attribute vec4 _glesMultiTexCoord0;
uniform highp vec4 _Time;
uniform highp mat4 glstate_matrix_mvp;
uniform mediump float _ScrollX;
uniform mediump float _ScrollY;
uniform mediump float _ScaleX;
uniform mediump float _ScaleY;
uniform mediump float _Seed;
uniform highp vec4 _MainTex_ST;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  highp vec2 tmpvar_1;
  tmpvar_1 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  highp float tmpvar_2;
  tmpvar_2 = (_Time.x + _Seed);
  highp vec2 tmpvar_3;
  tmpvar_3.x = ((tmpvar_1.x * _ScaleX) + (tmpvar_2 * _ScrollX));
  tmpvar_3.y = ((tmpvar_1.y * _ScaleY) + (tmpvar_2 * _ScrollY));
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = tmpvar_1;
  xlv_TEXCOORD1 = tmpvar_3;
  xlv_COLOR = _glesColor;
}



#endif
#ifdef FRAGMENT

uniform sampler2D _MainTex;
uniform mediump float _TexIntensity;
uniform lowp vec4 _Color;
uniform highp float _Intensity;
uniform sampler2D _FxTex;
uniform mediump float _FxIntensity;
uniform mediump float _FxDistortion;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  mediump vec4 col_1;
  lowp vec4 tmpvar_2;
  tmpvar_2 = texture2D (_FxTex, xlv_TEXCOORD1);
  mediump float tmpvar_3;
  tmpvar_3 = (tmpvar_2 * _FxIntensity).x;
  highp vec2 tmpvar_4;
  tmpvar_4.x = (xlv_TEXCOORD0.x + ((tmpvar_3 * 0.01) * _FxDistortion));
  tmpvar_4.y = (xlv_TEXCOORD0.y + ((tmpvar_3 * 0.005) * _FxDistortion));
  lowp vec4 tmpvar_5;
  tmpvar_5 = texture2D (_MainTex, tmpvar_4);
  mediump vec4 tmpvar_6;
  tmpvar_6 = (tmpvar_5 * _TexIntensity);
  col_1.xyz = ((_Color.xyz * vec3(tmpvar_3)) * 2.0);
  col_1.w = tmpvar_3;
  highp vec4 tmpvar_7;
  tmpvar_7 = (((
    (((2.0 * (col_1 * vec4(tmpvar_3))) * _Intensity) * xlv_COLOR)
   + tmpvar_6) * tmpvar_6.w) * _Color.w);
  col_1 = tmpvar_7;
  mediump float tmpvar_8;
  tmpvar_8 = dot (vec3(0.3, 0.59, 0.11), col_1.xyz);
  mediump vec4 tmpvar_9;
  tmpvar_9.x = tmpvar_8;
  tmpvar_9.y = tmpvar_8;
  tmpvar_9.z = tmpvar_8;
  tmpvar_9.w = col_1.w;
  mediump vec4 tmpvar_10;
  tmpvar_10 = (mix (col_1, tmpvar_9, vec4(0.7, 0.7, 0.7, 0.7)) * vec4(1.2, 1.2, 1.7, 1.4));
  col_1 = tmpvar_10;
  lowp vec4 tmpvar_11;
  tmpvar_11 = clamp (tmpvar_10, 0.0, 1.0);
  gl_FragData[0] = tmpvar_11;
}



#endif"
}
SubProgram "gles3 " {
"!!GLES3#version 300 es


#ifdef VERTEX


in vec4 _glesVertex;
in vec4 _glesColor;
in vec4 _glesMultiTexCoord0;
uniform highp vec4 _Time;
uniform highp mat4 glstate_matrix_mvp;
uniform mediump float _ScrollX;
uniform mediump float _ScrollY;
uniform mediump float _ScaleX;
uniform mediump float _ScaleY;
uniform mediump float _Seed;
uniform highp vec4 _MainTex_ST;
out highp vec2 xlv_TEXCOORD0;
out highp vec2 xlv_TEXCOORD1;
out lowp vec4 xlv_COLOR;
void main ()
{
  highp vec2 tmpvar_1;
  tmpvar_1 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  highp float tmpvar_2;
  tmpvar_2 = (_Time.x + _Seed);
  highp vec2 tmpvar_3;
  tmpvar_3.x = ((tmpvar_1.x * _ScaleX) + (tmpvar_2 * _ScrollX));
  tmpvar_3.y = ((tmpvar_1.y * _ScaleY) + (tmpvar_2 * _ScrollY));
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = tmpvar_1;
  xlv_TEXCOORD1 = tmpvar_3;
  xlv_COLOR = _glesColor;
}



#endif
#ifdef FRAGMENT


layout(location=0) out mediump vec4 _glesFragData[4];
uniform sampler2D _MainTex;
uniform mediump float _TexIntensity;
uniform lowp vec4 _Color;
uniform highp float _Intensity;
uniform sampler2D _FxTex;
uniform mediump float _FxIntensity;
uniform mediump float _FxDistortion;
in highp vec2 xlv_TEXCOORD0;
in highp vec2 xlv_TEXCOORD1;
in lowp vec4 xlv_COLOR;
void main ()
{
  mediump vec4 col_1;
  lowp vec4 tmpvar_2;
  tmpvar_2 = texture (_FxTex, xlv_TEXCOORD1);
  mediump float tmpvar_3;
  tmpvar_3 = (tmpvar_2 * _FxIntensity).x;
  highp vec2 tmpvar_4;
  tmpvar_4.x = (xlv_TEXCOORD0.x + ((tmpvar_3 * 0.01) * _FxDistortion));
  tmpvar_4.y = (xlv_TEXCOORD0.y + ((tmpvar_3 * 0.005) * _FxDistortion));
  lowp vec4 tmpvar_5;
  tmpvar_5 = texture (_MainTex, tmpvar_4);
  mediump vec4 tmpvar_6;
  tmpvar_6 = (tmpvar_5 * _TexIntensity);
  col_1.xyz = ((_Color.xyz * vec3(tmpvar_3)) * 2.0);
  col_1.w = tmpvar_3;
  highp vec4 tmpvar_7;
  tmpvar_7 = (((
    (((2.0 * (col_1 * vec4(tmpvar_3))) * _Intensity) * xlv_COLOR)
   + tmpvar_6) * tmpvar_6.w) * _Color.w);
  col_1 = tmpvar_7;
  mediump float tmpvar_8;
  tmpvar_8 = dot (vec3(0.3, 0.59, 0.11), col_1.xyz);
  mediump vec4 tmpvar_9;
  tmpvar_9.x = tmpvar_8;
  tmpvar_9.y = tmpvar_8;
  tmpvar_9.z = tmpvar_8;
  tmpvar_9.w = col_1.w;
  mediump vec4 tmpvar_10;
  tmpvar_10 = (mix (col_1, tmpvar_9, vec4(0.7, 0.7, 0.7, 0.7)) * vec4(1.2, 1.2, 1.7, 1.4));
  col_1 = tmpvar_10;
  lowp vec4 tmpvar_11;
  tmpvar_11 = clamp (tmpvar_10, 0.0, 1.0);
  _glesFragData[0] = tmpvar_11;
}



#endif"
}
SubProgram "metal " {
Bind "vertex" ATTR0
Bind "color" ATTR1
Bind "texcoord" ATTR2
ConstBuffer "$Globals" 112
Matrix 16 [glstate_matrix_mvp]
Vector 0 [_Time]
ScalarHalf 80 [_ScrollX]
ScalarHalf 82 [_ScrollY]
ScalarHalf 84 [_ScaleX]
ScalarHalf 86 [_ScaleY]
ScalarHalf 88 [_Seed]
Vector 96 [_MainTex_ST]
"metal_vs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  float4 _glesVertex [[attribute(0)]];
  float4 _glesColor [[attribute(1)]];
  float4 _glesMultiTexCoord0 [[attribute(2)]];
};
struct xlatMtlShaderOutput {
  float4 gl_Position [[position]];
  float2 xlv_TEXCOORD0;
  float2 xlv_TEXCOORD1;
  half4 xlv_COLOR;
};
struct xlatMtlShaderUniform {
  float4 _Time;
  float4x4 glstate_matrix_mvp;
  half _ScrollX;
  half _ScrollY;
  half _ScaleX;
  half _ScaleY;
  half _Seed;
  float4 _MainTex_ST;
};
vertex xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]])
{
  xlatMtlShaderOutput _mtl_o;
  half4 tmpvar_1;
  tmpvar_1 = half4(_mtl_i._glesColor);
  float2 tmpvar_2;
  tmpvar_2 = ((_mtl_i._glesMultiTexCoord0.xy * _mtl_u._MainTex_ST.xy) + _mtl_u._MainTex_ST.zw);
  float tmpvar_3;
  tmpvar_3 = (_mtl_u._Time.x + (float)_mtl_u._Seed);
  float2 tmpvar_4;
  tmpvar_4.x = ((tmpvar_2.x * (float)_mtl_u._ScaleX) + (tmpvar_3 * (float)_mtl_u._ScrollX));
  tmpvar_4.y = ((tmpvar_2.y * (float)_mtl_u._ScaleY) + (tmpvar_3 * (float)_mtl_u._ScrollY));
  _mtl_o.gl_Position = (_mtl_u.glstate_matrix_mvp * _mtl_i._glesVertex);
  _mtl_o.xlv_TEXCOORD0 = tmpvar_2;
  _mtl_o.xlv_TEXCOORD1 = tmpvar_4;
  _mtl_o.xlv_COLOR = tmpvar_1;
  return _mtl_o;
}

"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
SubProgram "gles3 " {
"!!GLES3"
}
SubProgram "metal " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_FxTex] 2D 1
ConstBuffer "$Globals" 24
ScalarHalf 0 [_TexIntensity]
VectorHalf 8 [_Color] 4
Float 16 [_Intensity]
ScalarHalf 20 [_FxIntensity]
ScalarHalf 22 [_FxDistortion]
"metal_fs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  float2 xlv_TEXCOORD0;
  float2 xlv_TEXCOORD1;
  half4 xlv_COLOR;
};
struct xlatMtlShaderOutput {
  half4 _glesFragData_0 [[color(0)]];
};
struct xlatMtlShaderUniform {
  half _TexIntensity;
  half4 _Color;
  float _Intensity;
  half _FxIntensity;
  half _FxDistortion;
};
fragment xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]]
  ,   texture2d<half> _MainTex [[texture(0)]], sampler _mtlsmp__MainTex [[sampler(0)]]
  ,   texture2d<half> _FxTex [[texture(1)]], sampler _mtlsmp__FxTex [[sampler(1)]])
{
  xlatMtlShaderOutput _mtl_o;
  half4 col_1;
  half4 tmpvar_2;
  tmpvar_2 = _FxTex.sample(_mtlsmp__FxTex, (float2)(_mtl_i.xlv_TEXCOORD1));
  half tmpvar_3;
  tmpvar_3 = (tmpvar_2 * _mtl_u._FxIntensity).x;
  float2 tmpvar_4;
  tmpvar_4.x = (_mtl_i.xlv_TEXCOORD0.x + (float)((tmpvar_3 * (half)0.01) * _mtl_u._FxDistortion));
  tmpvar_4.y = (_mtl_i.xlv_TEXCOORD0.y + (float)((tmpvar_3 * (half)0.005) * _mtl_u._FxDistortion));
  half4 tmpvar_5;
  tmpvar_5 = _MainTex.sample(_mtlsmp__MainTex, (float2)(tmpvar_4));
  half4 tmpvar_6;
  tmpvar_6 = (tmpvar_5 * _mtl_u._TexIntensity);
  col_1.xyz = ((_mtl_u._Color.xyz * half3(tmpvar_3)) * (half)2.0);
  col_1.w = tmpvar_3;
  float4 tmpvar_7;
  tmpvar_7 = (((
    (((float4)((half)2.0 * (col_1 * half4(tmpvar_3))) * _mtl_u._Intensity) * (float4)_mtl_i.xlv_COLOR)
   + (float4)tmpvar_6) * (float)tmpvar_6.w) * (float)_mtl_u._Color.w);
  col_1 = half4(tmpvar_7);
  half tmpvar_8;
  tmpvar_8 = dot ((half3)float3(0.3, 0.59, 0.11), col_1.xyz);
  half4 tmpvar_9;
  tmpvar_9.x = tmpvar_8;
  tmpvar_9.y = tmpvar_8;
  tmpvar_9.z = tmpvar_8;
  tmpvar_9.w = col_1.w;
  half4 tmpvar_10;
  tmpvar_10 = (mix (col_1, tmpvar_9, (half4)float4(0.7, 0.7, 0.7, 0.7)) * (half4)float4(1.2, 1.2, 1.7, 1.4));
  col_1 = tmpvar_10;
  half4 tmpvar_11;
  tmpvar_11 = clamp (tmpvar_10, (half)0.0, (half)1.0);
  _mtl_o._glesFragData_0 = tmpvar_11;
  return _mtl_o;
}

"
}
}
 }
}
Fallback Off
}