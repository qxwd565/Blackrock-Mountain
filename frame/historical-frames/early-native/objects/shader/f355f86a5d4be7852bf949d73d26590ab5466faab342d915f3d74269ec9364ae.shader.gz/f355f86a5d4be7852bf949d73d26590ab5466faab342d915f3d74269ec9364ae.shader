Shader "Effects/FX_Desaturate" {
Properties {
 _MainTex ("Base (RGB)", 2D) = "white" {}
 _Color ("Light Color", Color) = (0.6,0.6,0.6,1)
 _DarkColor ("Dark Color", Color) = (0.3,0.3,0.3,1)
 _Desaturate ("Desaturate", Float) = 1
 _Contrast ("Contrast", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _AvgLum ("Average Luminosity", Color) = (0.5,0.5,0.5,1)
}
SubShader { 
 Tags { "RenderType"="Opaque" }
 Pass {
  Tags { "RenderType"="Opaque" }
  BindChannels {
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

attribute vec4 _glesVertex;
attribute vec4 _glesMultiTexCoord0;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec4 _MainTex_ST;
varying highp vec2 xlv_TEXCOORD0;
void main ()
{
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
}



#endif
#ifdef FRAGMENT

uniform sampler2D _MainTex;
uniform lowp vec4 _Color;
uniform lowp vec4 _DarkColor;
uniform mediump float _Desaturate;
uniform highp float _Contrast;
uniform highp float _Intensity;
uniform lowp vec4 _AvgLum;
varying highp vec2 xlv_TEXCOORD0;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  lowp vec4 tmpvar_3;
  tmpvar_3 = texture2D (_MainTex, xlv_TEXCOORD0);
  col_2 = tmpvar_3;
  mediump vec4 tmpvar_4;
  tmpvar_4 = mix (col_2, mix (_DarkColor, _Color, vec4(dot (vec3(0.3, 0.59, 0.11), col_2.xyz))), vec4(_Desaturate));
  highp vec4 tmpvar_5;
  tmpvar_5 = mix (tmpvar_4, _AvgLum, vec4(_Contrast));
  col_2 = tmpvar_5;
  tmpvar_1 = (col_2 * _Intensity);
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "gles3 " {
"!!GLES3#version 300 es


#ifdef VERTEX


in vec4 _glesVertex;
in vec4 _glesMultiTexCoord0;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec4 _MainTex_ST;
out highp vec2 xlv_TEXCOORD0;
void main ()
{
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
}



#endif
#ifdef FRAGMENT


layout(location=0) out mediump vec4 _glesFragData[4];
uniform sampler2D _MainTex;
uniform lowp vec4 _Color;
uniform lowp vec4 _DarkColor;
uniform mediump float _Desaturate;
uniform highp float _Contrast;
uniform highp float _Intensity;
uniform lowp vec4 _AvgLum;
in highp vec2 xlv_TEXCOORD0;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  lowp vec4 tmpvar_3;
  tmpvar_3 = texture (_MainTex, xlv_TEXCOORD0);
  col_2 = tmpvar_3;
  mediump vec4 tmpvar_4;
  tmpvar_4 = mix (col_2, mix (_DarkColor, _Color, vec4(dot (vec3(0.3, 0.59, 0.11), col_2.xyz))), vec4(_Desaturate));
  highp vec4 tmpvar_5;
  tmpvar_5 = mix (tmpvar_4, _AvgLum, vec4(_Contrast));
  col_2 = tmpvar_5;
  tmpvar_1 = (col_2 * _Intensity);
  _glesFragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "metal " {
Bind "vertex" ATTR0
Bind "texcoord" ATTR1
ConstBuffer "$Globals" 80
Matrix 0 [glstate_matrix_mvp]
Vector 64 [_MainTex_ST]
"metal_vs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  float4 _glesVertex [[attribute(0)]];
  float4 _glesMultiTexCoord0 [[attribute(1)]];
};
struct xlatMtlShaderOutput {
  float4 gl_Position [[position]];
  float2 xlv_TEXCOORD0;
};
struct xlatMtlShaderUniform {
  float4x4 glstate_matrix_mvp;
  float4 _MainTex_ST;
};
vertex xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]])
{
  xlatMtlShaderOutput _mtl_o;
  _mtl_o.gl_Position = (_mtl_u.glstate_matrix_mvp * _mtl_i._glesVertex);
  _mtl_o.xlv_TEXCOORD0 = ((_mtl_i._glesMultiTexCoord0.xy * _mtl_u._MainTex_ST.xy) + _mtl_u._MainTex_ST.zw);
  return _mtl_o;
}

"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
SubProgram "gles3 " {
"!!GLES3"
}
SubProgram "metal " {
SetTexture 0 [_MainTex] 2D 0
ConstBuffer "$Globals" 40
VectorHalf 0 [_Color] 4
VectorHalf 8 [_DarkColor] 4
ScalarHalf 16 [_Desaturate]
Float 20 [_Contrast]
Float 24 [_Intensity]
VectorHalf 32 [_AvgLum] 4
"metal_fs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  float2 xlv_TEXCOORD0;
};
struct xlatMtlShaderOutput {
  half4 _glesFragData_0 [[color(0)]];
};
struct xlatMtlShaderUniform {
  half4 _Color;
  half4 _DarkColor;
  half _Desaturate;
  float _Contrast;
  float _Intensity;
  half4 _AvgLum;
};
fragment xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]]
  ,   texture2d<half> _MainTex [[texture(0)]], sampler _mtlsmp__MainTex [[sampler(0)]])
{
  xlatMtlShaderOutput _mtl_o;
  half4 tmpvar_1;
  half4 col_2;
  half4 tmpvar_3;
  tmpvar_3 = _MainTex.sample(_mtlsmp__MainTex, (float2)(_mtl_i.xlv_TEXCOORD0));
  col_2 = tmpvar_3;
  half4 tmpvar_4;
  tmpvar_4 = mix (col_2, mix (_mtl_u._DarkColor, _mtl_u._Color, half4(dot ((half3)float3(0.3, 0.59, 0.11), col_2.xyz))), half4(_mtl_u._Desaturate));
  float4 tmpvar_5;
  tmpvar_5 = mix ((float4)tmpvar_4, (float4)_mtl_u._AvgLum, float4(_mtl_u._Contrast));
  col_2 = half4(tmpvar_5);
  tmpvar_1 = half4(((float4)col_2 * _mtl_u._Intensity));
  _mtl_o._glesFragData_0 = tmpvar_1;
  return _mtl_o;
}

"
}
}
 }
}
Fallback Off
}