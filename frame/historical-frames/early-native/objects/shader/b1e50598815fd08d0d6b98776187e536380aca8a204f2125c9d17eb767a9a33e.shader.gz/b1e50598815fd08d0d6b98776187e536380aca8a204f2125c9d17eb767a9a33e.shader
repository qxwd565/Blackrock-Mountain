Shader "Hero/DiffuseAlphaMaskScroller" {
Properties {
 _MainTex ("_MainTex", 2D) = "black" {}
 _Intensity ("Intensity", Float) = 1
 _ScrollingTex ("_ScrollingTex", 2D) = "black" {}
 _tint ("_tint", Color) = (1,1,1,1)
 _Fade ("_Fade", Color) = (1,1,1,1)
 _YSpeed ("_YSpeed", Float) = 0.1
 _XSpeed ("_XSpeed", Float) = 0.1
 _ScaleX ("FX Scale X", Float) = 1
 _ScaleY ("FX Scale Y", Float) = 1
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "RenderType"="Opaque" }
 Pass {
  Tags { "RenderType"="Opaque" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "texcoord", TexCoord
   Bind "texcoord1", TexCoord1
  }
  Fog {
   Color (0,0,0,0)
  }
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

attribute vec4 _glesVertex;
attribute vec4 _glesMultiTexCoord0;
uniform highp vec4 _Time;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec4 glstate_lightmodel_ambient;
uniform lowp vec4 _LightColor0;
uniform mediump float _YSpeed;
uniform mediump float _XSpeed;
uniform mediump float _ScaleX;
uniform mediump float _ScaleY;
uniform mediump float _LightingBlend;
uniform highp vec4 _MainTex_ST;
varying highp vec4 xlv_TEXCOORD0;
varying lowp vec4 xlv_COLOR;
void main ()
{
  highp vec4 tmpvar_1;
  lowp vec4 tmpvar_2;
  highp vec2 tmpvar_3;
  tmpvar_3 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  tmpvar_1.xy = tmpvar_3;
  highp vec2 tmpvar_4;
  tmpvar_4.x = ((tmpvar_3.x * _ScaleX) + (_Time.x * _XSpeed));
  tmpvar_4.y = ((tmpvar_3.y * _ScaleY) + (_Time.x * _YSpeed));
  tmpvar_1.zw = tmpvar_4;
  highp vec4 tmpvar_5;
  tmpvar_5 = mix (vec4(1.0, 1.0, 1.0, 1.0), ((glstate_lightmodel_ambient * 2.0) + _LightColor0), vec4(_LightingBlend));
  tmpvar_2 = tmpvar_5;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = tmpvar_1;
  xlv_COLOR = tmpvar_2;
}



#endif
#ifdef FRAGMENT

uniform sampler2D _MainTex;
uniform mediump float _Intensity;
uniform sampler2D _ScrollingTex;
uniform mediump vec4 _tint;
uniform mediump vec4 _Fade;
varying highp vec4 xlv_TEXCOORD0;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 TexMask_2;
  mediump vec4 Tex2D1_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture2D (_MainTex, xlv_TEXCOORD0.xy);
  Tex2D1_3 = tmpvar_4;
  lowp vec4 tmpvar_5;
  tmpvar_5 = texture2D (_ScrollingTex, xlv_TEXCOORD0.zw);
  TexMask_2 = tmpvar_5;
  mediump vec4 tmpvar_6;
  tmpvar_6.w = 1.0;
  tmpvar_6.xyz = ((Tex2D1_3.xyz + (
    (((TexMask_2.x * _tint.xyz) * Tex2D1_3.w) * 1.5)
   * _Intensity)) * _Fade.xyz);
  tmpvar_1 = (tmpvar_6 * xlv_COLOR);
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "gles3 " {
"!!GLES3#version 300 es


#ifdef VERTEX


in vec4 _glesVertex;
in vec4 _glesMultiTexCoord0;
uniform highp vec4 _Time;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec4 glstate_lightmodel_ambient;
uniform lowp vec4 _LightColor0;
uniform mediump float _YSpeed;
uniform mediump float _XSpeed;
uniform mediump float _ScaleX;
uniform mediump float _ScaleY;
uniform mediump float _LightingBlend;
uniform highp vec4 _MainTex_ST;
out highp vec4 xlv_TEXCOORD0;
out lowp vec4 xlv_COLOR;
void main ()
{
  highp vec4 tmpvar_1;
  lowp vec4 tmpvar_2;
  highp vec2 tmpvar_3;
  tmpvar_3 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  tmpvar_1.xy = tmpvar_3;
  highp vec2 tmpvar_4;
  tmpvar_4.x = ((tmpvar_3.x * _ScaleX) + (_Time.x * _XSpeed));
  tmpvar_4.y = ((tmpvar_3.y * _ScaleY) + (_Time.x * _YSpeed));
  tmpvar_1.zw = tmpvar_4;
  highp vec4 tmpvar_5;
  tmpvar_5 = mix (vec4(1.0, 1.0, 1.0, 1.0), ((glstate_lightmodel_ambient * 2.0) + _LightColor0), vec4(_LightingBlend));
  tmpvar_2 = tmpvar_5;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = tmpvar_1;
  xlv_COLOR = tmpvar_2;
}



#endif
#ifdef FRAGMENT


layout(location=0) out mediump vec4 _glesFragData[4];
uniform sampler2D _MainTex;
uniform mediump float _Intensity;
uniform sampler2D _ScrollingTex;
uniform mediump vec4 _tint;
uniform mediump vec4 _Fade;
in highp vec4 xlv_TEXCOORD0;
in lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 TexMask_2;
  mediump vec4 Tex2D1_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture (_MainTex, xlv_TEXCOORD0.xy);
  Tex2D1_3 = tmpvar_4;
  lowp vec4 tmpvar_5;
  tmpvar_5 = texture (_ScrollingTex, xlv_TEXCOORD0.zw);
  TexMask_2 = tmpvar_5;
  mediump vec4 tmpvar_6;
  tmpvar_6.w = 1.0;
  tmpvar_6.xyz = ((Tex2D1_3.xyz + (
    (((TexMask_2.x * _tint.xyz) * Tex2D1_3.w) * 1.5)
   * _Intensity)) * _Fade.xyz);
  tmpvar_1 = (tmpvar_6 * xlv_COLOR);
  _glesFragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "metal " {
Bind "vertex" ATTR0
Bind "texcoord" ATTR1
ConstBuffer "$Globals" 144
Matrix 16 [glstate_matrix_mvp]
Vector 0 [_Time]
Vector 80 [glstate_lightmodel_ambient]
VectorHalf 96 [_LightColor0] 4
ScalarHalf 104 [_YSpeed]
ScalarHalf 106 [_XSpeed]
ScalarHalf 108 [_ScaleX]
ScalarHalf 110 [_ScaleY]
ScalarHalf 112 [_LightingBlend]
Vector 128 [_MainTex_ST]
"metal_vs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  float4 _glesVertex [[attribute(0)]];
  float4 _glesMultiTexCoord0 [[attribute(1)]];
};
struct xlatMtlShaderOutput {
  float4 gl_Position [[position]];
  float4 xlv_TEXCOORD0;
  half4 xlv_COLOR;
};
struct xlatMtlShaderUniform {
  float4 _Time;
  float4x4 glstate_matrix_mvp;
  float4 glstate_lightmodel_ambient;
  half4 _LightColor0;
  half _YSpeed;
  half _XSpeed;
  half _ScaleX;
  half _ScaleY;
  half _LightingBlend;
  float4 _MainTex_ST;
};
vertex xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]])
{
  xlatMtlShaderOutput _mtl_o;
  float4 tmpvar_1;
  half4 tmpvar_2;
  float2 tmpvar_3;
  tmpvar_3 = ((_mtl_i._glesMultiTexCoord0.xy * _mtl_u._MainTex_ST.xy) + _mtl_u._MainTex_ST.zw);
  tmpvar_1.xy = tmpvar_3;
  float2 tmpvar_4;
  tmpvar_4.x = ((tmpvar_3.x * (float)_mtl_u._ScaleX) + (_mtl_u._Time.x * (float)_mtl_u._XSpeed));
  tmpvar_4.y = ((tmpvar_3.y * (float)_mtl_u._ScaleY) + (_mtl_u._Time.x * (float)_mtl_u._YSpeed));
  tmpvar_1.zw = tmpvar_4;
  float4 tmpvar_5;
  tmpvar_5 = mix (float4(1.0, 1.0, 1.0, 1.0), ((_mtl_u.glstate_lightmodel_ambient * 2.0) + (float4)_mtl_u._LightColor0), (float4)half4(_mtl_u._LightingBlend));
  tmpvar_2 = half4(tmpvar_5);
  _mtl_o.gl_Position = (_mtl_u.glstate_matrix_mvp * _mtl_i._glesVertex);
  _mtl_o.xlv_TEXCOORD0 = tmpvar_1;
  _mtl_o.xlv_COLOR = tmpvar_2;
  return _mtl_o;
}

"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
SubProgram "gles3 " {
"!!GLES3"
}
SubProgram "metal " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_ScrollingTex] 2D 1
ConstBuffer "$Globals" 24
ScalarHalf 0 [_Intensity]
VectorHalf 8 [_tint] 4
VectorHalf 16 [_Fade] 4
"metal_fs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  float4 xlv_TEXCOORD0;
  half4 xlv_COLOR;
};
struct xlatMtlShaderOutput {
  half4 _glesFragData_0 [[color(0)]];
};
struct xlatMtlShaderUniform {
  half _Intensity;
  half4 _tint;
  half4 _Fade;
};
fragment xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]]
  ,   texture2d<half> _MainTex [[texture(0)]], sampler _mtlsmp__MainTex [[sampler(0)]]
  ,   texture2d<half> _ScrollingTex [[texture(1)]], sampler _mtlsmp__ScrollingTex [[sampler(1)]])
{
  xlatMtlShaderOutput _mtl_o;
  half4 tmpvar_1;
  half4 TexMask_2;
  half4 Tex2D1_3;
  half4 tmpvar_4;
  tmpvar_4 = _MainTex.sample(_mtlsmp__MainTex, (float2)(_mtl_i.xlv_TEXCOORD0.xy));
  Tex2D1_3 = tmpvar_4;
  half4 tmpvar_5;
  tmpvar_5 = _ScrollingTex.sample(_mtlsmp__ScrollingTex, (float2)(_mtl_i.xlv_TEXCOORD0.zw));
  TexMask_2 = tmpvar_5;
  half4 tmpvar_6;
  tmpvar_6.w = half(1.0);
  tmpvar_6.xyz = ((Tex2D1_3.xyz + (
    (((TexMask_2.x * _mtl_u._tint.xyz) * Tex2D1_3.w) * (half)1.5)
   * _mtl_u._Intensity)) * _mtl_u._Fade.xyz);
  tmpvar_1 = (tmpvar_6 * _mtl_i.xlv_COLOR);
  _mtl_o._glesFragData_0 = tmpvar_1;
  return _mtl_o;
}

"
}
}
 }
}
Fallback Off
}