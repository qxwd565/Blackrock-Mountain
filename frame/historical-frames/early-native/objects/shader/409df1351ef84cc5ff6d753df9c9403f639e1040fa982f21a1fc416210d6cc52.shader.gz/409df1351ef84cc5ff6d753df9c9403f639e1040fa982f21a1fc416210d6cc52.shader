Shader "Custom/Selection/Highlight" {
Properties {
 _Color ("Base Color", Color) = (0.5,0.5,0.5,1)
 _HiColor ("Hot Color", Color) = (0.5,0.5,0.5,1)
 _Colorize ("Colorize", Color) = (1,1,1,1)
 _ColorIntensity ("Color Intensity", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _MoteTex ("Mote Texture", 2D) = "white" {}
 _MoteIntensity ("Mote Intensity", Float) = 1
 _VmoteSpeed ("Mote V Speed", Float) = 1
 _UmoteScale ("Mote U Scale", Float) = 1
 _VmoteScale ("Mote V Scale", Float) = 1
 _FlareTex ("Flare Texture", 2D) = "white" {}
 _FlareIntensity ("Flare Intensity", Float) = 1
 _VflareSpeed ("Flare V Speed", Float) = 1
 _UflareScale ("Flare U Scale", Float) = 1
 _VflareScale ("Flare V Scale", Float) = 1
 _MainTex ("Main Texture", 2D) = "black" {}
 _Seed ("Seed", Float) = 0
}
SubShader { 
 Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
 Pass {
  Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  ZWrite Off
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
  Blend SrcAlpha OneMinusSrcAlpha
  ColorMask RGB
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

attribute vec4 _glesVertex;
attribute vec4 _glesColor;
attribute vec4 _glesMultiTexCoord0;
attribute vec4 _glesMultiTexCoord1;
uniform highp mat4 glstate_matrix_mvp;
uniform mediump float _Seed;
uniform highp vec4 _MainTex_ST;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  highp vec2 tmpvar_1;
  tmpvar_1.x = (_glesMultiTexCoord1.x + _Seed);
  tmpvar_1.y = _glesMultiTexCoord1.y;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_TEXCOORD1 = ((tmpvar_1 * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_COLOR = _glesColor;
}



#endif
#ifdef FRAGMENT

uniform highp vec4 _Time;
uniform sampler2D _MainTex;
uniform sampler2D _MoteTex;
uniform sampler2D _FlareTex;
uniform lowp vec4 _Color;
uniform lowp vec4 _Colorize;
uniform mediump vec4 _HiColor;
uniform mediump float _ColorIntensity;
uniform mediump float _Intensity;
uniform mediump float _FlareIntensity;
uniform mediump float _MoteIntensity;
uniform mediump float _VmoteSpeed;
uniform mediump float _UmoteScale;
uniform mediump float _VmoteScale;
uniform mediump float _VflareSpeed;
uniform mediump float _UflareScale;
uniform mediump float _VflareScale;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  mediump vec4 mote_3;
  mediump float flare_4;
  highp float v_5;
  lowp vec4 tmpvar_6;
  tmpvar_6 = texture2D (_MainTex, xlv_TEXCOORD0);
  mediump float tmpvar_7;
  tmpvar_7 = (tmpvar_6.x * _Intensity);
  v_5 = tmpvar_7;
  highp vec2 tmpvar_8;
  tmpvar_8.x = ((xlv_TEXCOORD1.x * _UflareScale) + fract((_Time.x * 0.05)));
  tmpvar_8.y = ((v_5 * _VflareScale) + fract((_Time.x * _VflareSpeed)));
  highp vec2 tmpvar_9;
  tmpvar_9.x = (xlv_TEXCOORD1.x * _UmoteScale);
  tmpvar_9.y = ((v_5 * _VmoteScale) + fract((_Time.x * _VmoteSpeed)));
  lowp vec4 tmpvar_10;
  tmpvar_10 = texture2D (_FlareTex, tmpvar_8);
  highp float tmpvar_11;
  tmpvar_11 = ((tmpvar_10.x * _FlareIntensity) * v_5);
  flare_4 = tmpvar_11;
  lowp vec4 tmpvar_12;
  tmpvar_12 = texture2D (_MoteTex, tmpvar_9);
  highp vec4 tmpvar_13;
  tmpvar_13 = (((
    (clamp (((
      (tmpvar_12 * xlv_COLOR.x)
     * 0.5) + v_5), 0.0, 1.0) + flare_4)
   * _MoteIntensity) * v_5) * xlv_COLOR.x);
  mote_3 = tmpvar_13;
  col_2.xyz = (mix (_Color, (
    (_HiColor * mote_3)
   + flare_4), mote_3) * _ColorIntensity).xyz;
  col_2.w = mote_3.x;
  tmpvar_1 = (col_2 * _Colorize);
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "gles3 " {
"!!GLES3#version 300 es


#ifdef VERTEX


in vec4 _glesVertex;
in vec4 _glesColor;
in vec4 _glesMultiTexCoord0;
in vec4 _glesMultiTexCoord1;
uniform highp mat4 glstate_matrix_mvp;
uniform mediump float _Seed;
uniform highp vec4 _MainTex_ST;
out highp vec2 xlv_TEXCOORD0;
out highp vec2 xlv_TEXCOORD1;
out lowp vec4 xlv_COLOR;
void main ()
{
  highp vec2 tmpvar_1;
  tmpvar_1.x = (_glesMultiTexCoord1.x + _Seed);
  tmpvar_1.y = _glesMultiTexCoord1.y;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_TEXCOORD1 = ((tmpvar_1 * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_COLOR = _glesColor;
}



#endif
#ifdef FRAGMENT


layout(location=0) out mediump vec4 _glesFragData[4];
uniform highp vec4 _Time;
uniform sampler2D _MainTex;
uniform sampler2D _MoteTex;
uniform sampler2D _FlareTex;
uniform lowp vec4 _Color;
uniform lowp vec4 _Colorize;
uniform mediump vec4 _HiColor;
uniform mediump float _ColorIntensity;
uniform mediump float _Intensity;
uniform mediump float _FlareIntensity;
uniform mediump float _MoteIntensity;
uniform mediump float _VmoteSpeed;
uniform mediump float _UmoteScale;
uniform mediump float _VmoteScale;
uniform mediump float _VflareSpeed;
uniform mediump float _UflareScale;
uniform mediump float _VflareScale;
in highp vec2 xlv_TEXCOORD0;
in highp vec2 xlv_TEXCOORD1;
in lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  mediump vec4 mote_3;
  mediump float flare_4;
  highp float v_5;
  lowp vec4 tmpvar_6;
  tmpvar_6 = texture (_MainTex, xlv_TEXCOORD0);
  mediump float tmpvar_7;
  tmpvar_7 = (tmpvar_6.x * _Intensity);
  v_5 = tmpvar_7;
  highp vec2 tmpvar_8;
  tmpvar_8.x = ((xlv_TEXCOORD1.x * _UflareScale) + fract((_Time.x * 0.05)));
  tmpvar_8.y = ((v_5 * _VflareScale) + fract((_Time.x * _VflareSpeed)));
  highp vec2 tmpvar_9;
  tmpvar_9.x = (xlv_TEXCOORD1.x * _UmoteScale);
  tmpvar_9.y = ((v_5 * _VmoteScale) + fract((_Time.x * _VmoteSpeed)));
  lowp vec4 tmpvar_10;
  tmpvar_10 = texture (_FlareTex, tmpvar_8);
  highp float tmpvar_11;
  tmpvar_11 = ((tmpvar_10.x * _FlareIntensity) * v_5);
  flare_4 = tmpvar_11;
  lowp vec4 tmpvar_12;
  tmpvar_12 = texture (_MoteTex, tmpvar_9);
  highp vec4 tmpvar_13;
  tmpvar_13 = (((
    (clamp (((
      (tmpvar_12 * xlv_COLOR.x)
     * 0.5) + v_5), 0.0, 1.0) + flare_4)
   * _MoteIntensity) * v_5) * xlv_COLOR.x);
  mote_3 = tmpvar_13;
  col_2.xyz = (mix (_Color, (
    (_HiColor * mote_3)
   + flare_4), mote_3) * _ColorIntensity).xyz;
  col_2.w = mote_3.x;
  tmpvar_1 = (col_2 * _Colorize);
  _glesFragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "metal " {
Bind "vertex" ATTR0
Bind "color" ATTR1
Bind "texcoord" ATTR2
Bind "texcoord1" ATTR3
ConstBuffer "$Globals" 96
Matrix 0 [glstate_matrix_mvp]
ScalarHalf 64 [_Seed]
Vector 80 [_MainTex_ST]
"metal_vs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  float4 _glesVertex [[attribute(0)]];
  float4 _glesColor [[attribute(1)]];
  float4 _glesMultiTexCoord0 [[attribute(2)]];
  float4 _glesMultiTexCoord1 [[attribute(3)]];
};
struct xlatMtlShaderOutput {
  float4 gl_Position [[position]];
  float2 xlv_TEXCOORD0;
  float2 xlv_TEXCOORD1;
  half4 xlv_COLOR;
};
struct xlatMtlShaderUniform {
  float4x4 glstate_matrix_mvp;
  half _Seed;
  float4 _MainTex_ST;
};
vertex xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]])
{
  xlatMtlShaderOutput _mtl_o;
  half4 tmpvar_1;
  tmpvar_1 = half4(_mtl_i._glesColor);
  float2 tmpvar_2;
  tmpvar_2.x = (_mtl_i._glesMultiTexCoord1.x + (float)_mtl_u._Seed);
  tmpvar_2.y = _mtl_i._glesMultiTexCoord1.y;
  _mtl_o.gl_Position = (_mtl_u.glstate_matrix_mvp * _mtl_i._glesVertex);
  _mtl_o.xlv_TEXCOORD0 = ((_mtl_i._glesMultiTexCoord0.xy * _mtl_u._MainTex_ST.xy) + _mtl_u._MainTex_ST.zw);
  _mtl_o.xlv_TEXCOORD1 = ((tmpvar_2 * _mtl_u._MainTex_ST.xy) + _mtl_u._MainTex_ST.zw);
  _mtl_o.xlv_COLOR = tmpvar_1;
  return _mtl_o;
}

"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
SubProgram "gles3 " {
"!!GLES3"
}
SubProgram "metal " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_MoteTex] 2D 1
SetTexture 2 [_FlareTex] 2D 2
ConstBuffer "$Globals" 60
Vector 0 [_Time]
VectorHalf 16 [_Color] 4
VectorHalf 24 [_Colorize] 4
VectorHalf 32 [_HiColor] 4
ScalarHalf 40 [_ColorIntensity]
ScalarHalf 42 [_Intensity]
ScalarHalf 44 [_FlareIntensity]
ScalarHalf 46 [_MoteIntensity]
ScalarHalf 48 [_VmoteSpeed]
ScalarHalf 50 [_UmoteScale]
ScalarHalf 52 [_VmoteScale]
ScalarHalf 54 [_VflareSpeed]
ScalarHalf 56 [_UflareScale]
ScalarHalf 58 [_VflareScale]
"metal_fs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  float2 xlv_TEXCOORD0;
  float2 xlv_TEXCOORD1;
  half4 xlv_COLOR;
};
struct xlatMtlShaderOutput {
  half4 _glesFragData_0 [[color(0)]];
};
struct xlatMtlShaderUniform {
  float4 _Time;
  half4 _Color;
  half4 _Colorize;
  half4 _HiColor;
  half _ColorIntensity;
  half _Intensity;
  half _FlareIntensity;
  half _MoteIntensity;
  half _VmoteSpeed;
  half _UmoteScale;
  half _VmoteScale;
  half _VflareSpeed;
  half _UflareScale;
  half _VflareScale;
};
fragment xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]]
  ,   texture2d<half> _MainTex [[texture(0)]], sampler _mtlsmp__MainTex [[sampler(0)]]
  ,   texture2d<half> _MoteTex [[texture(1)]], sampler _mtlsmp__MoteTex [[sampler(1)]]
  ,   texture2d<half> _FlareTex [[texture(2)]], sampler _mtlsmp__FlareTex [[sampler(2)]])
{
  xlatMtlShaderOutput _mtl_o;
  half4 tmpvar_1;
  half4 col_2;
  half4 mote_3;
  half flare_4;
  float v_5;
  half4 tmpvar_6;
  tmpvar_6 = _MainTex.sample(_mtlsmp__MainTex, (float2)(_mtl_i.xlv_TEXCOORD0));
  half tmpvar_7;
  tmpvar_7 = (tmpvar_6.x * _mtl_u._Intensity);
  v_5 = float(tmpvar_7);
  float2 tmpvar_8;
  tmpvar_8.x = ((_mtl_i.xlv_TEXCOORD1.x * (float)_mtl_u._UflareScale) + fract((_mtl_u._Time.x * 0.05)));
  tmpvar_8.y = ((v_5 * (float)_mtl_u._VflareScale) + fract((_mtl_u._Time.x * (float)_mtl_u._VflareSpeed)));
  float2 tmpvar_9;
  tmpvar_9.x = (_mtl_i.xlv_TEXCOORD1.x * (float)_mtl_u._UmoteScale);
  tmpvar_9.y = ((v_5 * (float)_mtl_u._VmoteScale) + fract((_mtl_u._Time.x * (float)_mtl_u._VmoteSpeed)));
  half4 tmpvar_10;
  tmpvar_10 = _FlareTex.sample(_mtlsmp__FlareTex, (float2)(tmpvar_8));
  float tmpvar_11;
  tmpvar_11 = ((float)(tmpvar_10.x * _mtl_u._FlareIntensity) * v_5);
  flare_4 = half(tmpvar_11);
  half4 tmpvar_12;
  tmpvar_12 = _MoteTex.sample(_mtlsmp__MoteTex, (float2)(tmpvar_9));
  float4 tmpvar_13;
  tmpvar_13 = (((float4)(
    ((half4)(clamp (((float4)(
      (tmpvar_12 * _mtl_i.xlv_COLOR.x)
     * (half)0.5) + v_5), 0.0, 1.0) + (float)flare_4))
   * _mtl_u._MoteIntensity) * v_5) * (float)_mtl_i.xlv_COLOR.x);
  mote_3 = half4(tmpvar_13);
  col_2.xyz = (mix (_mtl_u._Color, (
    (_mtl_u._HiColor * mote_3)
   + flare_4), mote_3) * _mtl_u._ColorIntensity).xyz;
  col_2.w = mote_3.x;
  tmpvar_1 = (col_2 * _mtl_u._Colorize);
  _mtl_o._glesFragData_0 = tmpvar_1;
  return _mtl_o;
}

"
}
}
 }
}
Fallback Off
}