Shader "Custom/Card/Unlit_Portrait" {
Properties {
 _Color ("Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _MainTex ("Main Texture", 2D) = "white" {}
 _SecondTex ("Second Texture", 2D) = "white" {}
 _SecondTint ("Second Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _BlendIntensity ("Blend Intensity", Float) = 2
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "RenderType"="Opaque" "Highlight"="true" }
 Pass {
  Tags { "RenderType"="Opaque" "Highlight"="true" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  Fog {
   Color (0,0,0,0)
  }
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

attribute vec4 _glesVertex;
attribute vec4 _glesColor;
attribute vec4 _glesMultiTexCoord0;
attribute vec4 _glesMultiTexCoord1;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec4 glstate_lightmodel_ambient;
uniform lowp vec4 _LightColor0;
uniform lowp vec4 _Color;
uniform mediump float _LightingBlend;
uniform highp vec4 _MainTex_ST;
uniform highp vec4 _SecondTex_ST;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  highp vec4 tmpvar_2;
  tmpvar_2 = (mix (_glesColor, (
    (glstate_lightmodel_ambient * 2.0)
   + _LightColor0), vec4(_LightingBlend)) * _Color);
  tmpvar_1 = tmpvar_2;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_TEXCOORD1 = ((_glesMultiTexCoord1.xy * _SecondTex_ST.xy) + _SecondTex_ST.zw);
  xlv_COLOR = tmpvar_1;
}



#endif
#ifdef FRAGMENT

uniform sampler2D _MainTex;
uniform sampler2D _SecondTex;
uniform lowp vec4 _SecondTint;
uniform mediump float _BlendIntensity;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  mediump vec4 main_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture2D (_MainTex, xlv_TEXCOORD0);
  main_3 = tmpvar_4;
  lowp vec4 tmpvar_5;
  tmpvar_5 = texture2D (_SecondTex, xlv_TEXCOORD1);
  mediump vec4 tmpvar_6;
  tmpvar_6 = ((tmpvar_5 * _SecondTint) * _BlendIntensity);
  col_2.xyz = mix (main_3, (main_3 * tmpvar_6), tmpvar_6.wwww).xyz;
  col_2.w = 1.0;
  mediump vec4 tmpvar_7;
  tmpvar_7 = min (((col_2 + 0.15) * xlv_COLOR), col_2);
  tmpvar_1 = tmpvar_7;
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "gles3 " {
"!!GLES3#version 300 es


#ifdef VERTEX


in vec4 _glesVertex;
in vec4 _glesColor;
in vec4 _glesMultiTexCoord0;
in vec4 _glesMultiTexCoord1;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec4 glstate_lightmodel_ambient;
uniform lowp vec4 _LightColor0;
uniform lowp vec4 _Color;
uniform mediump float _LightingBlend;
uniform highp vec4 _MainTex_ST;
uniform highp vec4 _SecondTex_ST;
out highp vec2 xlv_TEXCOORD0;
out highp vec2 xlv_TEXCOORD1;
out lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  highp vec4 tmpvar_2;
  tmpvar_2 = (mix (_glesColor, (
    (glstate_lightmodel_ambient * 2.0)
   + _LightColor0), vec4(_LightingBlend)) * _Color);
  tmpvar_1 = tmpvar_2;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_TEXCOORD1 = ((_glesMultiTexCoord1.xy * _SecondTex_ST.xy) + _SecondTex_ST.zw);
  xlv_COLOR = tmpvar_1;
}



#endif
#ifdef FRAGMENT


layout(location=0) out mediump vec4 _glesFragData[4];
uniform sampler2D _MainTex;
uniform sampler2D _SecondTex;
uniform lowp vec4 _SecondTint;
uniform mediump float _BlendIntensity;
in highp vec2 xlv_TEXCOORD0;
in highp vec2 xlv_TEXCOORD1;
in lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  mediump vec4 main_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture (_MainTex, xlv_TEXCOORD0);
  main_3 = tmpvar_4;
  lowp vec4 tmpvar_5;
  tmpvar_5 = texture (_SecondTex, xlv_TEXCOORD1);
  mediump vec4 tmpvar_6;
  tmpvar_6 = ((tmpvar_5 * _SecondTint) * _BlendIntensity);
  col_2.xyz = mix (main_3, (main_3 * tmpvar_6), tmpvar_6.wwww).xyz;
  col_2.w = 1.0;
  mediump vec4 tmpvar_7;
  tmpvar_7 = min (((col_2 + 0.15) * xlv_COLOR), col_2);
  tmpvar_1 = tmpvar_7;
  _glesFragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "metal " {
Bind "vertex" ATTR0
Bind "color" ATTR1
Bind "texcoord" ATTR2
Bind "texcoord1" ATTR3
ConstBuffer "$Globals" 144
Matrix 0 [glstate_matrix_mvp]
Vector 64 [glstate_lightmodel_ambient]
VectorHalf 80 [_LightColor0] 4
VectorHalf 88 [_Color] 4
ScalarHalf 96 [_LightingBlend]
Vector 112 [_MainTex_ST]
Vector 128 [_SecondTex_ST]
"metal_vs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  float4 _glesVertex [[attribute(0)]];
  float4 _glesColor [[attribute(1)]];
  float4 _glesMultiTexCoord0 [[attribute(2)]];
  float4 _glesMultiTexCoord1 [[attribute(3)]];
};
struct xlatMtlShaderOutput {
  float4 gl_Position [[position]];
  float2 xlv_TEXCOORD0;
  float2 xlv_TEXCOORD1;
  half4 xlv_COLOR;
};
struct xlatMtlShaderUniform {
  float4x4 glstate_matrix_mvp;
  float4 glstate_lightmodel_ambient;
  half4 _LightColor0;
  half4 _Color;
  half _LightingBlend;
  float4 _MainTex_ST;
  float4 _SecondTex_ST;
};
vertex xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]])
{
  xlatMtlShaderOutput _mtl_o;
  half4 tmpvar_1;
  tmpvar_1 = half4(_mtl_i._glesColor);
  half4 tmpvar_2;
  float4 tmpvar_3;
  tmpvar_3 = (mix ((float4)tmpvar_1, (
    (_mtl_u.glstate_lightmodel_ambient * 2.0)
   + (float4)_mtl_u._LightColor0), (float4)half4(_mtl_u._LightingBlend)) * (float4)_mtl_u._Color);
  tmpvar_2 = half4(tmpvar_3);
  _mtl_o.gl_Position = (_mtl_u.glstate_matrix_mvp * _mtl_i._glesVertex);
  _mtl_o.xlv_TEXCOORD0 = ((_mtl_i._glesMultiTexCoord0.xy * _mtl_u._MainTex_ST.xy) + _mtl_u._MainTex_ST.zw);
  _mtl_o.xlv_TEXCOORD1 = ((_mtl_i._glesMultiTexCoord1.xy * _mtl_u._SecondTex_ST.xy) + _mtl_u._SecondTex_ST.zw);
  _mtl_o.xlv_COLOR = tmpvar_2;
  return _mtl_o;
}

"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
SubProgram "gles3 " {
"!!GLES3"
}
SubProgram "metal " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SecondTex] 2D 1
ConstBuffer "$Globals" 10
VectorHalf 0 [_SecondTint] 4
ScalarHalf 8 [_BlendIntensity]
"metal_fs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  float2 xlv_TEXCOORD0;
  float2 xlv_TEXCOORD1;
  half4 xlv_COLOR;
};
struct xlatMtlShaderOutput {
  half4 _glesFragData_0 [[color(0)]];
};
struct xlatMtlShaderUniform {
  half4 _SecondTint;
  half _BlendIntensity;
};
fragment xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]]
  ,   texture2d<half> _MainTex [[texture(0)]], sampler _mtlsmp__MainTex [[sampler(0)]]
  ,   texture2d<half> _SecondTex [[texture(1)]], sampler _mtlsmp__SecondTex [[sampler(1)]])
{
  xlatMtlShaderOutput _mtl_o;
  half4 tmpvar_1;
  half4 col_2;
  half4 main_3;
  half4 tmpvar_4;
  tmpvar_4 = _MainTex.sample(_mtlsmp__MainTex, (float2)(_mtl_i.xlv_TEXCOORD0));
  main_3 = tmpvar_4;
  half4 tmpvar_5;
  tmpvar_5 = _SecondTex.sample(_mtlsmp__SecondTex, (float2)(_mtl_i.xlv_TEXCOORD1));
  half4 tmpvar_6;
  tmpvar_6 = ((tmpvar_5 * _mtl_u._SecondTint) * _mtl_u._BlendIntensity);
  col_2.xyz = mix (main_3, (main_3 * tmpvar_6), tmpvar_6.wwww).xyz;
  col_2.w = half(1.0);
  half4 tmpvar_7;
  tmpvar_7 = min (((col_2 + (half)0.15) * _mtl_i.xlv_COLOR), col_2);
  tmpvar_1 = tmpvar_7;
  _mtl_o._glesFragData_0 = tmpvar_1;
  return _mtl_o;
}

"
}
}
 }
}
Fallback "Diffuse"
}