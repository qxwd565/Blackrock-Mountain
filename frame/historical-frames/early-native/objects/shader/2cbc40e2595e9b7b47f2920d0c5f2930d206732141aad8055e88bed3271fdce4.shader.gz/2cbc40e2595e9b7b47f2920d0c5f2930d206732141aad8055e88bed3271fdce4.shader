Shader "Hero/AddMultiplyFXScrolling" {
Properties {
 _Color ("Tint Color", Color) = (0.5,0.5,0.5,0.5)
 _MainTex ("Main Texture", 2D) = "white" {}
 _Intensity ("Intensity", Float) = 1
 _FxTex ("FX Texture", 2D) = "white" {}
 _FxIntensity ("FX Intensity", Float) = 1
 _ScrollX ("FX Scroll X", Float) = 0
 _ScrollY ("FX Scroll Y", Float) = 0
 _ScaleX ("FX Scale X", Float) = 1
 _ScaleY ("FX Scale Y", Float) = 1
 _GlowColor ("Glow Color", Color) = (1,1,1,1)
 _GlowIntensity ("Glow Intensity", Float) = 0
 _GlowAddMul ("Glow Add/Multiply", Range(0,1)) = 0
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="GlowTransparent" }
 Pass {
  Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="GlowTransparent" }
  BindChannels {
   Bind "vertex", Vertex
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  ZWrite Off
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
  Blend One OneMinusSrcAlpha
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

attribute vec4 _glesVertex;
attribute vec4 _glesColor;
attribute vec4 _glesMultiTexCoord0;
uniform highp vec4 _Time;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec4 glstate_lightmodel_ambient;
uniform lowp vec4 _LightColor0;
uniform lowp vec4 _Color;
uniform mediump float _ScrollX;
uniform mediump float _ScrollY;
uniform mediump float _ScaleX;
uniform mediump float _ScaleY;
uniform mediump float _LightingBlend;
uniform highp vec4 _MainTex_ST;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  highp vec2 tmpvar_2;
  tmpvar_2 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  highp vec2 tmpvar_3;
  tmpvar_3.x = ((tmpvar_2.x * _ScaleX) + (_Time.x * _ScrollX));
  tmpvar_3.y = ((tmpvar_2.y * _ScaleY) + (_Time.x * _ScrollY));
  highp vec4 tmpvar_4;
  tmpvar_4 = (mix (_glesColor, (
    ((glstate_lightmodel_ambient * 2.0) + _LightColor0)
   * _glesColor), vec4(_LightingBlend)) * _Color.w);
  tmpvar_1 = tmpvar_4;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = tmpvar_2;
  xlv_TEXCOORD1 = tmpvar_3;
  xlv_COLOR = tmpvar_1;
}



#endif
#ifdef FRAGMENT

uniform sampler2D _MainTex;
uniform lowp vec4 _Color;
uniform highp float _Intensity;
uniform sampler2D _FxTex;
uniform highp float _FxIntensity;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  mediump vec4 fx_3;
  mediump vec4 tex_4;
  lowp vec4 tmpvar_5;
  tmpvar_5 = texture2D (_MainTex, xlv_TEXCOORD0);
  tex_4 = tmpvar_5;
  lowp vec4 tmpvar_6;
  tmpvar_6 = texture2D (_FxTex, xlv_TEXCOORD1);
  highp vec4 tmpvar_7;
  tmpvar_7 = (tmpvar_6 * _FxIntensity);
  fx_3 = tmpvar_7;
  col_2.xyz = (_Color.xyz * tex_4.xyz);
  col_2.w = (tex_4.w * (_Color.w - tex_4.w));
  tmpvar_1 = (((2.0 * 
    (col_2 * fx_3)
  ) * _Intensity) * xlv_COLOR);
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "gles3 " {
"!!GLES3#version 300 es


#ifdef VERTEX


in vec4 _glesVertex;
in vec4 _glesColor;
in vec4 _glesMultiTexCoord0;
uniform highp vec4 _Time;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec4 glstate_lightmodel_ambient;
uniform lowp vec4 _LightColor0;
uniform lowp vec4 _Color;
uniform mediump float _ScrollX;
uniform mediump float _ScrollY;
uniform mediump float _ScaleX;
uniform mediump float _ScaleY;
uniform mediump float _LightingBlend;
uniform highp vec4 _MainTex_ST;
out highp vec2 xlv_TEXCOORD0;
out highp vec2 xlv_TEXCOORD1;
out lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  highp vec2 tmpvar_2;
  tmpvar_2 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  highp vec2 tmpvar_3;
  tmpvar_3.x = ((tmpvar_2.x * _ScaleX) + (_Time.x * _ScrollX));
  tmpvar_3.y = ((tmpvar_2.y * _ScaleY) + (_Time.x * _ScrollY));
  highp vec4 tmpvar_4;
  tmpvar_4 = (mix (_glesColor, (
    ((glstate_lightmodel_ambient * 2.0) + _LightColor0)
   * _glesColor), vec4(_LightingBlend)) * _Color.w);
  tmpvar_1 = tmpvar_4;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = tmpvar_2;
  xlv_TEXCOORD1 = tmpvar_3;
  xlv_COLOR = tmpvar_1;
}



#endif
#ifdef FRAGMENT


layout(location=0) out mediump vec4 _glesFragData[4];
uniform sampler2D _MainTex;
uniform lowp vec4 _Color;
uniform highp float _Intensity;
uniform sampler2D _FxTex;
uniform highp float _FxIntensity;
in highp vec2 xlv_TEXCOORD0;
in highp vec2 xlv_TEXCOORD1;
in lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  mediump vec4 fx_3;
  mediump vec4 tex_4;
  lowp vec4 tmpvar_5;
  tmpvar_5 = texture (_MainTex, xlv_TEXCOORD0);
  tex_4 = tmpvar_5;
  lowp vec4 tmpvar_6;
  tmpvar_6 = texture (_FxTex, xlv_TEXCOORD1);
  highp vec4 tmpvar_7;
  tmpvar_7 = (tmpvar_6 * _FxIntensity);
  fx_3 = tmpvar_7;
  col_2.xyz = (_Color.xyz * tex_4.xyz);
  col_2.w = (tex_4.w * (_Color.w - tex_4.w));
  tmpvar_1 = (((2.0 * 
    (col_2 * fx_3)
  ) * _Intensity) * xlv_COLOR);
  _glesFragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "metal " {
Bind "vertex" ATTR0
Bind "color" ATTR1
Bind "texcoord" ATTR2
ConstBuffer "$Globals" 144
Matrix 16 [glstate_matrix_mvp]
Vector 0 [_Time]
Vector 80 [glstate_lightmodel_ambient]
VectorHalf 96 [_LightColor0] 4
VectorHalf 104 [_Color] 4
ScalarHalf 112 [_ScrollX]
ScalarHalf 114 [_ScrollY]
ScalarHalf 116 [_ScaleX]
ScalarHalf 118 [_ScaleY]
ScalarHalf 120 [_LightingBlend]
Vector 128 [_MainTex_ST]
"metal_vs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  float4 _glesVertex [[attribute(0)]];
  float4 _glesColor [[attribute(1)]];
  float4 _glesMultiTexCoord0 [[attribute(2)]];
};
struct xlatMtlShaderOutput {
  float4 gl_Position [[position]];
  float2 xlv_TEXCOORD0;
  float2 xlv_TEXCOORD1;
  half4 xlv_COLOR;
};
struct xlatMtlShaderUniform {
  float4 _Time;
  float4x4 glstate_matrix_mvp;
  float4 glstate_lightmodel_ambient;
  half4 _LightColor0;
  half4 _Color;
  half _ScrollX;
  half _ScrollY;
  half _ScaleX;
  half _ScaleY;
  half _LightingBlend;
  float4 _MainTex_ST;
};
vertex xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]])
{
  xlatMtlShaderOutput _mtl_o;
  half4 tmpvar_1;
  tmpvar_1 = half4(_mtl_i._glesColor);
  half4 tmpvar_2;
  float2 tmpvar_3;
  tmpvar_3 = ((_mtl_i._glesMultiTexCoord0.xy * _mtl_u._MainTex_ST.xy) + _mtl_u._MainTex_ST.zw);
  float2 tmpvar_4;
  tmpvar_4.x = ((tmpvar_3.x * (float)_mtl_u._ScaleX) + (_mtl_u._Time.x * (float)_mtl_u._ScrollX));
  tmpvar_4.y = ((tmpvar_3.y * (float)_mtl_u._ScaleY) + (_mtl_u._Time.x * (float)_mtl_u._ScrollY));
  float4 tmpvar_5;
  tmpvar_5 = (mix ((float4)tmpvar_1, (
    ((_mtl_u.glstate_lightmodel_ambient * 2.0) + (float4)_mtl_u._LightColor0)
   * (float4)tmpvar_1), (float4)half4(_mtl_u._LightingBlend)) * (float)_mtl_u._Color.w);
  tmpvar_2 = half4(tmpvar_5);
  _mtl_o.gl_Position = (_mtl_u.glstate_matrix_mvp * _mtl_i._glesVertex);
  _mtl_o.xlv_TEXCOORD0 = tmpvar_3;
  _mtl_o.xlv_TEXCOORD1 = tmpvar_4;
  _mtl_o.xlv_COLOR = tmpvar_2;
  return _mtl_o;
}

"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
SubProgram "gles3 " {
"!!GLES3"
}
SubProgram "metal " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_FxTex] 2D 1
ConstBuffer "$Globals" 16
VectorHalf 0 [_Color] 4
Float 8 [_Intensity]
Float 12 [_FxIntensity]
"metal_fs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  float2 xlv_TEXCOORD0;
  float2 xlv_TEXCOORD1;
  half4 xlv_COLOR;
};
struct xlatMtlShaderOutput {
  half4 _glesFragData_0 [[color(0)]];
};
struct xlatMtlShaderUniform {
  half4 _Color;
  float _Intensity;
  float _FxIntensity;
};
fragment xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]]
  ,   texture2d<half> _MainTex [[texture(0)]], sampler _mtlsmp__MainTex [[sampler(0)]]
  ,   texture2d<half> _FxTex [[texture(1)]], sampler _mtlsmp__FxTex [[sampler(1)]])
{
  xlatMtlShaderOutput _mtl_o;
  half4 tmpvar_1;
  half4 col_2;
  half4 fx_3;
  half4 tex_4;
  half4 tmpvar_5;
  tmpvar_5 = _MainTex.sample(_mtlsmp__MainTex, (float2)(_mtl_i.xlv_TEXCOORD0));
  tex_4 = tmpvar_5;
  half4 tmpvar_6;
  tmpvar_6 = _FxTex.sample(_mtlsmp__FxTex, (float2)(_mtl_i.xlv_TEXCOORD1));
  float4 tmpvar_7;
  tmpvar_7 = ((float4)tmpvar_6 * _mtl_u._FxIntensity);
  fx_3 = half4(tmpvar_7);
  col_2.xyz = (_mtl_u._Color.xyz * tex_4.xyz);
  col_2.w = (tex_4.w * (_mtl_u._Color.w - tex_4.w));
  tmpvar_1 = half4((((float4)((half)2.0 * 
    (col_2 * fx_3)
  ) * _mtl_u._Intensity) * (float4)_mtl_i.xlv_COLOR));
  _mtl_o._glesFragData_0 = tmpvar_1;
  return _mtl_o;
}

"
}
}
 }
}
Fallback Off
}