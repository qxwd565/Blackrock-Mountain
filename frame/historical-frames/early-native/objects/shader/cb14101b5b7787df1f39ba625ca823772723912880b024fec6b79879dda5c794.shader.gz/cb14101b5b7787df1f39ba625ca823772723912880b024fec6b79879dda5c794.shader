Shader "Custom/Card/UnlitTextureReflection" {
Properties {
 _MainTex ("Base (RGB)", 2D) = "white" {}
 _SpecTex ("Specular (RGB)", 2D) = "white" {}
 _ReflTex ("Reflection (RGB)", 2D) = "white" {}
 _ReflectionIntensity ("Reflection Intensity", Float) = 1
 _ReflectionColor ("Reflection Color", Color) = (0.8,0.8,0.8,1)
 _ReflectionFalloffColor ("Reflection Falloff Color", Color) = (0.3,0.3,0.3,1)
 _ReflectionFalloff ("Reflection Falloff", Float) = 2.5
 _ReflectionRotation ("Reflection Rotation", Float) = 1
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
 _Seed ("Seed", Float) = 0
}
SubShader { 
 Tags { "LIGHTMODE"="Always" "RenderType"="Opaque" "Highlight"="true" }
 Pass {
  Tags { "LIGHTMODE"="Always" "RenderType"="Opaque" "Highlight"="true" }
  BindChannels {
   Bind "color", Color
   Bind "normal", Normal
   Bind "texcoord", TexCoord
  }
  Cull Off
  Fog {
   Color (0,0,0,1)
  }
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

attribute vec4 _glesVertex;
attribute vec3 _glesNormal;
attribute vec4 _glesMultiTexCoord0;
uniform highp vec3 _WorldSpaceCameraPos;
uniform highp mat4 glstate_matrix_mvp;
uniform highp mat4 _Object2World;
uniform highp vec4 unity_Scale;
uniform highp vec4 glstate_lightmodel_ambient;
uniform lowp vec4 _LightColor0;
uniform lowp vec4 _ReflectionColor;
uniform lowp vec4 _ReflectionFalloffColor;
uniform mediump float _ReflectionFalloff;
uniform mediump float _ReflectionRotation;
uniform mediump float _LightingBlend;
uniform highp float _ShaderTime;
uniform highp vec4 _MainTex_ST;
varying lowp vec4 xlv_COLOR;
varying lowp vec4 xlv_COLOR1;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
void main ()
{
  mediump float falloff_1;
  mediump vec3 ws_2;
  lowp vec4 tmpvar_3;
  lowp vec4 tmpvar_4;
  highp vec2 tmpvar_5;
  highp vec2 tmpvar_6;
  tmpvar_6 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  highp mat3 tmpvar_7;
  tmpvar_7[0] = _Object2World[0].xyz;
  tmpvar_7[1] = _Object2World[1].xyz;
  tmpvar_7[2] = _Object2World[2].xyz;
  highp vec3 tmpvar_8;
  tmpvar_8 = ((tmpvar_7 * (
    normalize(_glesNormal)
   * unity_Scale.w)) * 0.3);
  highp vec3 tmpvar_9;
  highp vec4 cse_10;
  cse_10 = (_Object2World * _glesVertex);
  tmpvar_9 = cse_10.xyz;
  ws_2 = tmpvar_9;
  tmpvar_5 = (((
    -(tmpvar_6.x)
   * tmpvar_8) + ws_2) * 0.07).xz;
  tmpvar_5 = (tmpvar_5 + (_ShaderTime * _ReflectionRotation));
  highp float tmpvar_11;
  tmpvar_11 = abs(dot (normalize(
    (_WorldSpaceCameraPos - cse_10.xyz)
  ), tmpvar_8));
  falloff_1 = tmpvar_11;
  mediump float tmpvar_12;
  tmpvar_12 = pow (falloff_1, _ReflectionFalloff);
  falloff_1 = tmpvar_12;
  mediump vec4 tmpvar_13;
  tmpvar_13 = mix (_ReflectionFalloffColor, _ReflectionColor, vec4(tmpvar_12));
  tmpvar_3 = tmpvar_13;
  highp vec4 tmpvar_14;
  tmpvar_14 = mix (vec4(1.0, 1.0, 1.0, 1.0), ((glstate_lightmodel_ambient * 2.0) + _LightColor0), vec4(_LightingBlend));
  tmpvar_4 = tmpvar_14;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_COLOR = tmpvar_3;
  xlv_COLOR1 = tmpvar_4;
  xlv_TEXCOORD0 = tmpvar_6;
  xlv_TEXCOORD1 = tmpvar_5;
}



#endif
#ifdef FRAGMENT

uniform sampler2D _MainTex;
uniform sampler2D _SpecTex;
uniform sampler2D _ReflTex;
uniform mediump float _ReflectionIntensity;
varying lowp vec4 xlv_COLOR;
varying lowp vec4 xlv_COLOR1;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
void main ()
{
  mediump vec4 mask_1;
  mediump vec4 col_2;
  lowp vec4 tmpvar_3;
  tmpvar_3 = texture2D (_MainTex, xlv_TEXCOORD0);
  col_2 = tmpvar_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture2D (_SpecTex, xlv_TEXCOORD0);
  mask_1 = tmpvar_4;
  lowp vec4 tmpvar_5;
  highp vec2 P_6;
  P_6 = (xlv_TEXCOORD1 * 2.0);
  tmpvar_5 = texture2D (_ReflTex, P_6);
  mediump vec4 x_7;
  x_7 = ((col_2 + (
    ((tmpvar_5 * mask_1) * _ReflectionIntensity)
   * xlv_COLOR)) * xlv_COLOR1);
  lowp vec4 tmpvar_8;
  tmpvar_8 = clamp (x_7, 0.0, 1.0);
  gl_FragData[0] = tmpvar_8;
}



#endif"
}
SubProgram "gles3 " {
"!!GLES3#version 300 es


#ifdef VERTEX


in vec4 _glesVertex;
in vec3 _glesNormal;
in vec4 _glesMultiTexCoord0;
uniform highp vec3 _WorldSpaceCameraPos;
uniform highp mat4 glstate_matrix_mvp;
uniform highp mat4 _Object2World;
uniform highp vec4 unity_Scale;
uniform highp vec4 glstate_lightmodel_ambient;
uniform lowp vec4 _LightColor0;
uniform lowp vec4 _ReflectionColor;
uniform lowp vec4 _ReflectionFalloffColor;
uniform mediump float _ReflectionFalloff;
uniform mediump float _ReflectionRotation;
uniform mediump float _LightingBlend;
uniform highp float _ShaderTime;
uniform highp vec4 _MainTex_ST;
out lowp vec4 xlv_COLOR;
out lowp vec4 xlv_COLOR1;
out highp vec2 xlv_TEXCOORD0;
out highp vec2 xlv_TEXCOORD1;
void main ()
{
  mediump float falloff_1;
  mediump vec3 ws_2;
  lowp vec4 tmpvar_3;
  lowp vec4 tmpvar_4;
  highp vec2 tmpvar_5;
  highp vec2 tmpvar_6;
  tmpvar_6 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  highp mat3 tmpvar_7;
  tmpvar_7[0] = _Object2World[0].xyz;
  tmpvar_7[1] = _Object2World[1].xyz;
  tmpvar_7[2] = _Object2World[2].xyz;
  highp vec3 tmpvar_8;
  tmpvar_8 = ((tmpvar_7 * (
    normalize(_glesNormal)
   * unity_Scale.w)) * 0.3);
  highp vec3 tmpvar_9;
  highp vec4 cse_10;
  cse_10 = (_Object2World * _glesVertex);
  tmpvar_9 = cse_10.xyz;
  ws_2 = tmpvar_9;
  tmpvar_5 = (((
    -(tmpvar_6.x)
   * tmpvar_8) + ws_2) * 0.07).xz;
  tmpvar_5 = (tmpvar_5 + (_ShaderTime * _ReflectionRotation));
  highp float tmpvar_11;
  tmpvar_11 = abs(dot (normalize(
    (_WorldSpaceCameraPos - cse_10.xyz)
  ), tmpvar_8));
  falloff_1 = tmpvar_11;
  mediump float tmpvar_12;
  tmpvar_12 = pow (falloff_1, _ReflectionFalloff);
  falloff_1 = tmpvar_12;
  mediump vec4 tmpvar_13;
  tmpvar_13 = mix (_ReflectionFalloffColor, _ReflectionColor, vec4(tmpvar_12));
  tmpvar_3 = tmpvar_13;
  highp vec4 tmpvar_14;
  tmpvar_14 = mix (vec4(1.0, 1.0, 1.0, 1.0), ((glstate_lightmodel_ambient * 2.0) + _LightColor0), vec4(_LightingBlend));
  tmpvar_4 = tmpvar_14;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_COLOR = tmpvar_3;
  xlv_COLOR1 = tmpvar_4;
  xlv_TEXCOORD0 = tmpvar_6;
  xlv_TEXCOORD1 = tmpvar_5;
}



#endif
#ifdef FRAGMENT


layout(location=0) out mediump vec4 _glesFragData[4];
uniform sampler2D _MainTex;
uniform sampler2D _SpecTex;
uniform sampler2D _ReflTex;
uniform mediump float _ReflectionIntensity;
in lowp vec4 xlv_COLOR;
in lowp vec4 xlv_COLOR1;
in highp vec2 xlv_TEXCOORD0;
in highp vec2 xlv_TEXCOORD1;
void main ()
{
  mediump vec4 mask_1;
  mediump vec4 col_2;
  lowp vec4 tmpvar_3;
  tmpvar_3 = texture (_MainTex, xlv_TEXCOORD0);
  col_2 = tmpvar_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture (_SpecTex, xlv_TEXCOORD0);
  mask_1 = tmpvar_4;
  lowp vec4 tmpvar_5;
  highp vec2 P_6;
  P_6 = (xlv_TEXCOORD1 * 2.0);
  tmpvar_5 = texture (_ReflTex, P_6);
  mediump vec4 x_7;
  x_7 = ((col_2 + (
    ((tmpvar_5 * mask_1) * _ReflectionIntensity)
   * xlv_COLOR)) * xlv_COLOR1);
  lowp vec4 tmpvar_8;
  tmpvar_8 = clamp (x_7, 0.0, 1.0);
  _glesFragData[0] = tmpvar_8;
}



#endif"
}
SubProgram "metal " {
Bind "vertex" ATTR0
Bind "normal" ATTR1
Bind "texcoord" ATTR2
ConstBuffer "$Globals" 240
Matrix 16 [glstate_matrix_mvp]
Matrix 80 [_Object2World]
Vector 0 [_WorldSpaceCameraPos] 3
Vector 144 [unity_Scale]
Vector 160 [glstate_lightmodel_ambient]
VectorHalf 176 [_LightColor0] 4
VectorHalf 184 [_ReflectionColor] 4
VectorHalf 192 [_ReflectionFalloffColor] 4
ScalarHalf 200 [_ReflectionFalloff]
ScalarHalf 202 [_ReflectionRotation]
ScalarHalf 204 [_LightingBlend]
Float 208 [_ShaderTime]
Vector 224 [_MainTex_ST]
"metal_vs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  float4 _glesVertex [[attribute(0)]];
  float3 _glesNormal [[attribute(1)]];
  float4 _glesMultiTexCoord0 [[attribute(2)]];
};
struct xlatMtlShaderOutput {
  float4 gl_Position [[position]];
  half4 xlv_COLOR;
  half4 xlv_COLOR1;
  float2 xlv_TEXCOORD0;
  float2 xlv_TEXCOORD1;
};
struct xlatMtlShaderUniform {
  float3 _WorldSpaceCameraPos;
  float4x4 glstate_matrix_mvp;
  float4x4 _Object2World;
  float4 unity_Scale;
  float4 glstate_lightmodel_ambient;
  half4 _LightColor0;
  half4 _ReflectionColor;
  half4 _ReflectionFalloffColor;
  half _ReflectionFalloff;
  half _ReflectionRotation;
  half _LightingBlend;
  float _ShaderTime;
  float4 _MainTex_ST;
};
vertex xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]])
{
  xlatMtlShaderOutput _mtl_o;
  half falloff_1;
  half3 ws_2;
  half4 tmpvar_3;
  half4 tmpvar_4;
  float2 tmpvar_5;
  float2 tmpvar_6;
  tmpvar_6 = ((_mtl_i._glesMultiTexCoord0.xy * _mtl_u._MainTex_ST.xy) + _mtl_u._MainTex_ST.zw);
  float3x3 tmpvar_7;
  tmpvar_7[0] = _mtl_u._Object2World[0].xyz;
  tmpvar_7[1] = _mtl_u._Object2World[1].xyz;
  tmpvar_7[2] = _mtl_u._Object2World[2].xyz;
  float3 tmpvar_8;
  tmpvar_8 = ((tmpvar_7 * (
    normalize(_mtl_i._glesNormal)
   * _mtl_u.unity_Scale.w)) * 0.3);
  float3 tmpvar_9;
  float4 cse_10;
  cse_10 = (_mtl_u._Object2World * _mtl_i._glesVertex);
  tmpvar_9 = cse_10.xyz;
  ws_2 = half3(tmpvar_9);
  tmpvar_5 = (((
    -(tmpvar_6.x)
   * tmpvar_8) + (float3)ws_2) * 0.07).xz;
  tmpvar_5 = (tmpvar_5 + (_mtl_u._ShaderTime * (float)_mtl_u._ReflectionRotation));
  float tmpvar_11;
  tmpvar_11 = abs(dot (normalize(
    (_mtl_u._WorldSpaceCameraPos - cse_10.xyz)
  ), tmpvar_8));
  falloff_1 = half(tmpvar_11);
  half tmpvar_12;
  tmpvar_12 = pow (falloff_1, _mtl_u._ReflectionFalloff);
  falloff_1 = tmpvar_12;
  half4 tmpvar_13;
  tmpvar_13 = mix (_mtl_u._ReflectionFalloffColor, _mtl_u._ReflectionColor, half4(tmpvar_12));
  tmpvar_3 = tmpvar_13;
  float4 tmpvar_14;
  tmpvar_14 = mix (float4(1.0, 1.0, 1.0, 1.0), ((_mtl_u.glstate_lightmodel_ambient * 2.0) + (float4)_mtl_u._LightColor0), (float4)half4(_mtl_u._LightingBlend));
  tmpvar_4 = half4(tmpvar_14);
  _mtl_o.gl_Position = (_mtl_u.glstate_matrix_mvp * _mtl_i._glesVertex);
  _mtl_o.xlv_COLOR = tmpvar_3;
  _mtl_o.xlv_COLOR1 = tmpvar_4;
  _mtl_o.xlv_TEXCOORD0 = tmpvar_6;
  _mtl_o.xlv_TEXCOORD1 = tmpvar_5;
  return _mtl_o;
}

"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
SubProgram "gles3 " {
"!!GLES3"
}
SubProgram "metal " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SpecTex] 2D 1
SetTexture 2 [_ReflTex] 2D 2
ConstBuffer "$Globals" 2
ScalarHalf 0 [_ReflectionIntensity]
"metal_fs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  half4 xlv_COLOR;
  half4 xlv_COLOR1;
  float2 xlv_TEXCOORD0;
  float2 xlv_TEXCOORD1;
};
struct xlatMtlShaderOutput {
  half4 _glesFragData_0 [[color(0)]];
};
struct xlatMtlShaderUniform {
  half _ReflectionIntensity;
};
fragment xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]]
  ,   texture2d<half> _MainTex [[texture(0)]], sampler _mtlsmp__MainTex [[sampler(0)]]
  ,   texture2d<half> _SpecTex [[texture(1)]], sampler _mtlsmp__SpecTex [[sampler(1)]]
  ,   texture2d<half> _ReflTex [[texture(2)]], sampler _mtlsmp__ReflTex [[sampler(2)]])
{
  xlatMtlShaderOutput _mtl_o;
  half4 mask_1;
  half4 col_2;
  half4 tmpvar_3;
  tmpvar_3 = _MainTex.sample(_mtlsmp__MainTex, (float2)(_mtl_i.xlv_TEXCOORD0));
  col_2 = tmpvar_3;
  half4 tmpvar_4;
  tmpvar_4 = _SpecTex.sample(_mtlsmp__SpecTex, (float2)(_mtl_i.xlv_TEXCOORD0));
  mask_1 = tmpvar_4;
  half4 tmpvar_5;
  float2 P_6;
  P_6 = (_mtl_i.xlv_TEXCOORD1 * 2.0);
  tmpvar_5 = _ReflTex.sample(_mtlsmp__ReflTex, (float2)(P_6));
  half4 x_7;
  x_7 = ((col_2 + (
    ((tmpvar_5 * mask_1) * _mtl_u._ReflectionIntensity)
   * _mtl_i.xlv_COLOR)) * _mtl_i.xlv_COLOR1);
  half4 tmpvar_8;
  tmpvar_8 = clamp (x_7, (half)0.0, (half)1.0);
  _mtl_o._glesFragData_0 = tmpvar_8;
  return _mtl_o;
}

"
}
}
 }
}
Fallback "Diffuse"
}