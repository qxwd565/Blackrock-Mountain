Shader "Custom/Card/MissingCardDesaturateAlpha" {
Properties {
 _MainTex ("Base (RGB)", 2D) = "white" {}
 _SecondTex ("Second Texture", 2D) = "white" {}
 _SecondScaleUV ("Second UV Scale", Float) = 1
 _SecondIntensity ("SecondIntensity", Float) = 1
 _Color ("Color", Color) = (0.5,0.5,0.5,1)
 _Desaturate ("Desaturate", Float) = 1
 _Contrast ("Contrast", Float) = 1
 _Intensity ("Intensity", Float) = 1
 _AvgLum ("Average Luminosity", Color) = (0.5,0.5,0.5,1)
 _LightingBlend ("Ambient Lighting Blend", Float) = 0
}
SubShader { 
 Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
 Pass {
  Tags { "QUEUE"="Transparent" "IGNOREPROJECTOR"="true" "RenderType"="Transparent" }
  BindChannels {
   Bind "color", Color
   Bind "texcoord", TexCoord
  }
  Cull Off
  Fog { Mode Off }
  Blend SrcAlpha OneMinusSrcAlpha
Program "vp" {
SubProgram "gles " {
"!!GLES


#ifdef VERTEX

attribute vec4 _glesVertex;
attribute vec4 _glesColor;
attribute vec4 _glesMultiTexCoord0;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec4 glstate_lightmodel_ambient;
uniform lowp vec4 _LightColor0;
uniform mediump float _SecondScaleUV;
uniform mediump float _LightingBlend;
uniform highp vec4 _MainTex_ST;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  highp vec4 tmpvar_2;
  tmpvar_2 = mix (_glesColor, ((glstate_lightmodel_ambient * 2.0) + _LightColor0), vec4(_LightingBlend));
  tmpvar_1 = tmpvar_2;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_TEXCOORD1 = (_glesVertex.xz * _SecondScaleUV);
  xlv_COLOR = tmpvar_1;
}



#endif
#ifdef FRAGMENT

uniform sampler2D _MainTex;
uniform sampler2D _SecondTex;
uniform mediump float _SecondIntensity;
uniform lowp vec4 _Color;
uniform mediump float _Desaturate;
uniform mediump float _Contrast;
uniform mediump float _Intensity;
uniform lowp vec4 _AvgLum;
varying highp vec2 xlv_TEXCOORD0;
varying highp vec2 xlv_TEXCOORD1;
varying lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  lowp vec4 tmpvar_3;
  tmpvar_3 = texture2D (_MainTex, xlv_TEXCOORD0);
  col_2 = tmpvar_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture2D (_SecondTex, xlv_TEXCOORD1);
  mediump float tmpvar_5;
  tmpvar_5 = col_2.w;
  mediump float tmpvar_6;
  tmpvar_6 = dot (vec3(0.3, 0.59, 0.11), col_2.xyz);
  mediump vec4 tmpvar_7;
  tmpvar_7.x = tmpvar_6;
  tmpvar_7.y = tmpvar_6;
  tmpvar_7.z = tmpvar_6;
  tmpvar_7.w = col_2.w;
  col_2.xyz = mix (mix (col_2, tmpvar_7, vec4(_Desaturate)), _AvgLum, vec4(_Contrast)).xyz;
  col_2.w = (((1.0 - tmpvar_6) * tmpvar_5) * clamp ((tmpvar_4 * _SecondIntensity), 0.0, 1.0)).x;
  tmpvar_1 = (((col_2 * _Color) * _Intensity) * xlv_COLOR);
  gl_FragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "gles3 " {
"!!GLES3#version 300 es


#ifdef VERTEX


in vec4 _glesVertex;
in vec4 _glesColor;
in vec4 _glesMultiTexCoord0;
uniform highp mat4 glstate_matrix_mvp;
uniform highp vec4 glstate_lightmodel_ambient;
uniform lowp vec4 _LightColor0;
uniform mediump float _SecondScaleUV;
uniform mediump float _LightingBlend;
uniform highp vec4 _MainTex_ST;
out highp vec2 xlv_TEXCOORD0;
out highp vec2 xlv_TEXCOORD1;
out lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  highp vec4 tmpvar_2;
  tmpvar_2 = mix (_glesColor, ((glstate_lightmodel_ambient * 2.0) + _LightColor0), vec4(_LightingBlend));
  tmpvar_1 = tmpvar_2;
  gl_Position = (glstate_matrix_mvp * _glesVertex);
  xlv_TEXCOORD0 = ((_glesMultiTexCoord0.xy * _MainTex_ST.xy) + _MainTex_ST.zw);
  xlv_TEXCOORD1 = (_glesVertex.xz * _SecondScaleUV);
  xlv_COLOR = tmpvar_1;
}



#endif
#ifdef FRAGMENT


layout(location=0) out mediump vec4 _glesFragData[4];
uniform sampler2D _MainTex;
uniform sampler2D _SecondTex;
uniform mediump float _SecondIntensity;
uniform lowp vec4 _Color;
uniform mediump float _Desaturate;
uniform mediump float _Contrast;
uniform mediump float _Intensity;
uniform lowp vec4 _AvgLum;
in highp vec2 xlv_TEXCOORD0;
in highp vec2 xlv_TEXCOORD1;
in lowp vec4 xlv_COLOR;
void main ()
{
  lowp vec4 tmpvar_1;
  mediump vec4 col_2;
  lowp vec4 tmpvar_3;
  tmpvar_3 = texture (_MainTex, xlv_TEXCOORD0);
  col_2 = tmpvar_3;
  lowp vec4 tmpvar_4;
  tmpvar_4 = texture (_SecondTex, xlv_TEXCOORD1);
  mediump float tmpvar_5;
  tmpvar_5 = col_2.w;
  mediump float tmpvar_6;
  tmpvar_6 = dot (vec3(0.3, 0.59, 0.11), col_2.xyz);
  mediump vec4 tmpvar_7;
  tmpvar_7.x = tmpvar_6;
  tmpvar_7.y = tmpvar_6;
  tmpvar_7.z = tmpvar_6;
  tmpvar_7.w = col_2.w;
  col_2.xyz = mix (mix (col_2, tmpvar_7, vec4(_Desaturate)), _AvgLum, vec4(_Contrast)).xyz;
  col_2.w = (((1.0 - tmpvar_6) * tmpvar_5) * clamp ((tmpvar_4 * _SecondIntensity), 0.0, 1.0)).x;
  tmpvar_1 = (((col_2 * _Color) * _Intensity) * xlv_COLOR);
  _glesFragData[0] = tmpvar_1;
}



#endif"
}
SubProgram "metal " {
Bind "vertex" ATTR0
Bind "color" ATTR1
Bind "texcoord" ATTR2
ConstBuffer "$Globals" 112
Matrix 0 [glstate_matrix_mvp]
Vector 64 [glstate_lightmodel_ambient]
VectorHalf 80 [_LightColor0] 4
ScalarHalf 88 [_SecondScaleUV]
ScalarHalf 90 [_LightingBlend]
Vector 96 [_MainTex_ST]
"metal_vs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  float4 _glesVertex [[attribute(0)]];
  float4 _glesColor [[attribute(1)]];
  float4 _glesMultiTexCoord0 [[attribute(2)]];
};
struct xlatMtlShaderOutput {
  float4 gl_Position [[position]];
  float2 xlv_TEXCOORD0;
  float2 xlv_TEXCOORD1;
  half4 xlv_COLOR;
};
struct xlatMtlShaderUniform {
  float4x4 glstate_matrix_mvp;
  float4 glstate_lightmodel_ambient;
  half4 _LightColor0;
  half _SecondScaleUV;
  half _LightingBlend;
  float4 _MainTex_ST;
};
vertex xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]])
{
  xlatMtlShaderOutput _mtl_o;
  half4 tmpvar_1;
  tmpvar_1 = half4(_mtl_i._glesColor);
  half4 tmpvar_2;
  float4 tmpvar_3;
  tmpvar_3 = mix ((float4)tmpvar_1, ((_mtl_u.glstate_lightmodel_ambient * 2.0) + (float4)_mtl_u._LightColor0), (float4)half4(_mtl_u._LightingBlend));
  tmpvar_2 = half4(tmpvar_3);
  _mtl_o.gl_Position = (_mtl_u.glstate_matrix_mvp * _mtl_i._glesVertex);
  _mtl_o.xlv_TEXCOORD0 = ((_mtl_i._glesMultiTexCoord0.xy * _mtl_u._MainTex_ST.xy) + _mtl_u._MainTex_ST.zw);
  _mtl_o.xlv_TEXCOORD1 = (_mtl_i._glesVertex.xz * (float)_mtl_u._SecondScaleUV);
  _mtl_o.xlv_COLOR = tmpvar_2;
  return _mtl_o;
}

"
}
}
Program "fp" {
SubProgram "gles " {
"!!GLES"
}
SubProgram "gles3 " {
"!!GLES3"
}
SubProgram "metal " {
SetTexture 0 [_MainTex] 2D 0
SetTexture 1 [_SecondTex] 2D 1
ConstBuffer "$Globals" 32
ScalarHalf 0 [_SecondIntensity]
VectorHalf 8 [_Color] 4
ScalarHalf 16 [_Desaturate]
ScalarHalf 18 [_Contrast]
ScalarHalf 20 [_Intensity]
VectorHalf 24 [_AvgLum] 4
"metal_fs
#include <metal_stdlib>
using namespace metal;
struct xlatMtlShaderInput {
  float2 xlv_TEXCOORD0;
  float2 xlv_TEXCOORD1;
  half4 xlv_COLOR;
};
struct xlatMtlShaderOutput {
  half4 _glesFragData_0 [[color(0)]];
};
struct xlatMtlShaderUniform {
  half _SecondIntensity;
  half4 _Color;
  half _Desaturate;
  half _Contrast;
  half _Intensity;
  half4 _AvgLum;
};
fragment xlatMtlShaderOutput xlatMtlMain (xlatMtlShaderInput _mtl_i [[stage_in]], constant xlatMtlShaderUniform& _mtl_u [[buffer(0)]]
  ,   texture2d<half> _MainTex [[texture(0)]], sampler _mtlsmp__MainTex [[sampler(0)]]
  ,   texture2d<half> _SecondTex [[texture(1)]], sampler _mtlsmp__SecondTex [[sampler(1)]])
{
  xlatMtlShaderOutput _mtl_o;
  half4 tmpvar_1;
  half4 col_2;
  half4 tmpvar_3;
  tmpvar_3 = _MainTex.sample(_mtlsmp__MainTex, (float2)(_mtl_i.xlv_TEXCOORD0));
  col_2 = tmpvar_3;
  half4 tmpvar_4;
  tmpvar_4 = _SecondTex.sample(_mtlsmp__SecondTex, (float2)(_mtl_i.xlv_TEXCOORD1));
  half tmpvar_5;
  tmpvar_5 = col_2.w;
  half tmpvar_6;
  tmpvar_6 = dot ((half3)float3(0.3, 0.59, 0.11), col_2.xyz);
  half4 tmpvar_7;
  tmpvar_7.x = tmpvar_6;
  tmpvar_7.y = tmpvar_6;
  tmpvar_7.z = tmpvar_6;
  tmpvar_7.w = col_2.w;
  col_2.xyz = mix (mix (col_2, tmpvar_7, half4(_mtl_u._Desaturate)), _mtl_u._AvgLum, half4(_mtl_u._Contrast)).xyz;
  col_2.w = ((((half)1.0 - tmpvar_6) * tmpvar_5) * clamp ((tmpvar_4 * _mtl_u._SecondIntensity), (half)0.0, (half)1.0)).x;
  tmpvar_1 = (((col_2 * _mtl_u._Color) * _mtl_u._Intensity) * _mtl_i.xlv_COLOR);
  _mtl_o._glesFragData_0 = tmpvar_1;
  return _mtl_o;
}

"
}
}
 }
}
Fallback Off
}